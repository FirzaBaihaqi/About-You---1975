import unittest

from karaoke import parse_lrc, play_events


class ParseLrcTests(unittest.TestCase):
    def test_parses_timestamps_and_applies_offset(self):
        events = parse_lrc("[offset:100]\n[00:01.50][00:03.00]A lyric line\n[00:02.00]Another line")
        self.assertEqual(events, [(1.6, "A lyric line"), (2.1, "Another line"), (3.1, "A lyric line")])

    def test_ignores_metadata_and_blank_lines(self):
        events = parse_lrc("[ar:Artist]\n[ti:Title]\n\n[00:00.00]First line")
        self.assertEqual(events, [(0.0, "First line")])

    def test_rejects_lrc_without_timed_lyrics(self):
        with self.assertRaises(ValueError):
            parse_lrc("[ar:Artist]\njust text")


class PlayEventsTests(unittest.TestCase):
    def test_emits_each_line_at_its_scheduled_time(self):
        now = [0.0]
        output = []

        def fake_sleep(seconds):
            now[0] += seconds

        events = [(1.25, "First line"), (2.0, "Second line")]
        play_events(events, sleep=fake_sleep, clock=lambda: now[0], emit=output.append)

        self.assertEqual(output, ["[00:01] First line", "[00:02] Second line"])
        self.assertEqual(now[0], 2.0)


if __name__ == "__main__":
    unittest.main()
