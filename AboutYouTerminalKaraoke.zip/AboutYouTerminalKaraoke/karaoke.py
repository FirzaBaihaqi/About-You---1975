import argparse
import re
import sys
import time
from pathlib import Path
from typing import Callable


_TIMESTAMP = re.compile(r"\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]")
_OFFSET = re.compile(r"\[offset:([+-]?\d+)\]", re.IGNORECASE)


def parse_lrc(text: str) -> list[tuple[float, str]]:
    """Return sorted (seconds, lyric text) events from LRC-formatted text."""
    offset_ms = 0
    events: list[tuple[float, str]] = []

    for raw_line in text.splitlines():
        offset_match = _OFFSET.search(raw_line)
        if offset_match:
            offset_ms = int(offset_match.group(1))

        matches = list(_TIMESTAMP.finditer(raw_line))
        if not matches:
            continue

        lyric = _TIMESTAMP.sub("", raw_line).strip()
        if not lyric:
            continue

        for match in matches:
            minutes = int(match.group(1))
            seconds = int(match.group(2))
            fraction = match.group(3) or "0"
            fractional_seconds = int(fraction) / (10 ** len(fraction)) if match.group(3) else 0.0
            timestamp = minutes * 60 + seconds + fractional_seconds + offset_ms / 1000
            events.append((max(0.0, timestamp), lyric))

    events.sort(key=lambda event: event[0])
    if not events:
        raise ValueError("File LRC tidak berisi lirik bertimestamp.")
    return events


def play_events(
    events: list[tuple[float, str]],
    *,
    sleep: Callable[[float], None] = time.sleep,
    clock: Callable[[], float] = time.monotonic,
    emit: Callable[[str], None] = print,
    start_delay: float = 0.0,
) -> None:
    """Print each lyric line at its timestamp, relative to the start of playback."""
    started_at = clock() + max(0.0, start_delay)
    for timestamp, lyric in events:
        remaining = started_at + timestamp - clock()
        if remaining > 0:
            sleep(remaining)
        minutes, seconds = divmod(int(timestamp), 60)
        emit(f"[{minutes:02d}:{seconds:02d}] {lyric}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Tampilkan lirik LRC mengikuti timestamp di terminal."
    )
    parser.add_argument("file", type=Path, help="File lirik .lrc milikmu")
    parser.add_argument(
        "--delay", type=float, default=0,
        help="Jeda dalam detik setelah Enter sebelum lirik mulai (default: 0)",
    )
    parser.add_argument(
        "--no-prompt", action="store_true",
        help="Langsung mulai tanpa menunggu Enter",
    )
    args = parser.parse_args()

    try:
        events = parse_lrc(args.file.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        print(f"File tidak ditemukan: {args.file}", file=sys.stderr)
        return 1
    except (OSError, UnicodeError, ValueError) as error:
        print(f"Tidak bisa membaca lirik: {error}", file=sys.stderr)
        return 1

    if not args.no_prompt:
        print("Putar lagu dari awal di aplikasi musikmu, lalu tekan Enter tepat saat lagu mulai.")
        try:
            input("Tekan Enter untuk sinkronisasi... ")
        except (EOFError, KeyboardInterrupt):
            print("\nDibatalkan.")
            return 130

    try:
        play_events(events, start_delay=args.delay)
    except KeyboardInterrupt:
        print("\nPemutaran lirik dihentikan.")
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
