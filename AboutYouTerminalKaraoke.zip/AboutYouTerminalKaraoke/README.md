# About You — Terminal Lyrics

Program Python sederhana untuk menampilkan lirik bertimestamp di terminal VS Code. Program ini tidak memutar audio; putar lagu dari aplikasi musikmu, mulai dari awal, lalu tekan Enter tepat saat lagu mulai.

## Menjalankan

1. Buka folder ini di VS Code.
2. Isi `about_you.lrc` dengan lirik dan timestamp yang kamu punya atau berhak gunakan. Format satu baris:

   ```text
   [00:12.34]Teks lirik pada waktu tersebut
   [00:15.80]Baris berikutnya
   ```

   Timestamp memakai format `[menit:detik.milidetik]`. Baris metadata seperti `[ar:Nama artis]` juga boleh.
3. Buka terminal VS Code (`Terminal > New Terminal`), lalu jalankan:

   ```bash
   python karaoke.py about_you.lrc
   ```

4. Mulai lagu dari awal. Saat musik mulai, tekan Enter pada terminal.

Kalau timing perlu dikoreksi, tambahkan misalnya `--delay 2` untuk jeda 2 detik setelah Enter. Hentikan dengan `Ctrl+C`.

## Tes

Jalankan `python -m unittest -v` dari folder ini. Tidak perlu memasang paket tambahan.
